import setuptools
from distutils.core import setup

setup(name='sparkLDA',
      version='0.1',
      packages=['test'],
      py_modules=['config', 'processing', 'utils']
      )